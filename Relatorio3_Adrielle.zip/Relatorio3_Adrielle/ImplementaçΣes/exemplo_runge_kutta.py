import math
import metodos.runge_kutta_4_ordem as rk

def f(x, y):
    return y * math.cos(x)

with open('entrada/exemplo_runge_kutta.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]
n = int(valores[3])

yi, xi = rk.runge_kutta(f, x0, y0, h, n)

with open('saida/exemplo_runge_kutta.txt', 'w') as arquivo:
    arquivo.write(f"x       y       h=0.1\n\n")

    for x, y in zip(xi, yi):
        arquivo.write(f"{x:.1f}     {y}\n")