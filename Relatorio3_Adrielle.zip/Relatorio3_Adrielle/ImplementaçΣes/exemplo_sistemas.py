import math

import metodos.sistemas_edo as sis_edo

def f(x, y, z):
    dy_dz = z
    dz_dx = y + math.e**x

    return dy_dz, dz_dx

with open('entrada/exemplo_sistemas.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x = valores[:3]
y0 = int(valores[3])
z0 = int(valores[4])
h = valores[5]

Yn, Zn = sis_edo.sistemas_edo(f, x, y0, z0, h)

with open('saida/exemplo_sistemas.txt', 'w') as arquivo:
    arquivo.write(f"x       y           z       h=0.1\n\n")

    for x, y, z in zip(x, Yn, Zn):
        arquivo.write(f"{x:.1f}     {y:.4f}      {z:.4f}\n")