import math
import metodos.ralston as ralston

def f(x, y):
    return y / ((1-x) * (math.log(x-1) + 2))

with open('entrada/exemplo_ralston.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]
n = int(valores[3])

yi, xi = ralston.ralston(f, x0, y0, h, n)

with open('saida/exemplo_ralston.txt', 'w') as arquivo:
    arquivo.write(f"x        y       h=0.2\n\n")

    for x, y in zip(xi, yi):
        arquivo.write(f"{x:.1f}     {y:.4f}\n")