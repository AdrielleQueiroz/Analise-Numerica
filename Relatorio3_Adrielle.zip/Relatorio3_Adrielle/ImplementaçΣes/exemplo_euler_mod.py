import metodos.euler_modificado as euler_m

def f(x, y):
    return x - y + 2

with open('entrada/exemplo_euler_mod.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]
n = int(valores[3])

yi, xi = euler_m.euler_modificado(f, x0, y0, h, n)

with open('saida/exemplo_euler_mod.txt', 'w') as arquivo:
    arquivo.write(f"x        y       h=0.1\n\n")

    for x, y in zip(xi, yi):
        arquivo.write(f"{x:.1f}     {y:.4f}\n")