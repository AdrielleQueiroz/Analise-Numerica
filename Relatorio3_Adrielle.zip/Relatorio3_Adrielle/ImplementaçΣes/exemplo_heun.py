import metodos.heun as heun

def f(x, y):
    return 1 + x*y

with open('entrada/exemplo_heun.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]
n = int(valores[3])

y, x = heun.heun(f, x0, y0, h, n)

with open('saida/exemplo_heun.txt', 'w') as arquivo:
    arquivo.write(f"x        y       h=0.25\n\n")

    for xi, yi in zip(x, y):
        arquivo.write(f"{xi:.2f}     {yi:.4f}\n")
