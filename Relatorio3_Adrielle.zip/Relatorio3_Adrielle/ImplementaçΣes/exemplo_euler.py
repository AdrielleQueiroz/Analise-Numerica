import metodos.euler as euler

def f(x, y):
    return x/y - y/x

with open('entrada/exemplo_euler.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]

Yn, Xn = euler.euler(f, x0, y0, h, 2)

with open('saida/exemplo_euler.txt', 'w') as arquivo:
    arquivo.write(f"x       y       h=0.1\n\n")

    for x, y in zip(Xn, Yn):
        arquivo.write(f"{x:.1f}     {y}\n")

'''
print(f"x       y           h=0.1\n")
for x, y in zip(Xn, Yn):
    print(f"{x:.1f}     {y}")
'''