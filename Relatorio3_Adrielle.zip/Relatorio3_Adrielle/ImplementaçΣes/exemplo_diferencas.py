import numpy as np
import metodos.diferencas_finitas as df

def p(x):
    return x/3

def q(x):
    return -1

def r(x):
      return 6*x - 1

with open('entrada/exemplo_diferencas.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [int(valor.strip()) for valor in valores_str]

x0 = valores[0]
y0 = valores[1]
xf = valores[2]
yf = valores[3]
n = valores[4]

vetor_x = np.linspace(0 + 1/4, 1 - 1/4, 3)
y = df.diferenças_finitas(p, q, r, x0, y0, xf, yf, n)

with open('saida/exemplo_diferencas.txt', 'w') as arquivo:
    arquivo.write(f"Resolução do sistema linear resultante:\n\n")

    for i in range(len(y)):
        arquivo.write(f"y({vetor_x[i]}) = {y[i]}\n")

