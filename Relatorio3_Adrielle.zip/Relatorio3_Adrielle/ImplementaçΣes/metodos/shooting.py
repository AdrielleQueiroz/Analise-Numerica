import numpy as np
import matplotlib.pyplot as plt

def sistema_edos(x, u):
    return np.array([u[1], -u[0]])

def runge_kutta(h, x0, u0, ode_system):
    x_values = [x0]
    u_values = [u0]

    while x_values[-1] < np.pi / 2:
        x = x_values[-1]
        u = u_values[-1]
        k1 = h * ode_system(x, u)
        k2 = h * ode_system(x + h / 2, u + k1 / 2)
        k3 = h * ode_system(x + h / 2, u + k2 / 2)
        k4 = h * ode_system(x + h, u + k3)

        x_values.append(x + h)
        u_values.append(u + (k1 + 2 * k2 + 2 * k3 + k4) / 6)

    return np.array(x_values), np.array(u_values)

def shooting(tol=1e-6, max_iter=100):
    x0 = 0
    x_final = np.pi / 2
    u0_guess = [0, 1]  # Suposição inicial para u1(0) e u2(0)

    for _ in range(max_iter):
        x_values, u_values = runge_kutta(0.1, x0, u0_guess, sistema_edos)
        u_final = u_values[-1][0]

        if np.abs(u_final - 1) < tol:
            break

        # Ajuste da condição inicial
        u0_guess[0] -= (u_final - 1) / u_values[-1][1]

    return x_values, u_values

x_values, u_values = shooting()

print(x_values)
print(u_values)

'''
plt.plot(x_values, u_values[:, 0], label='Solution')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Solution using Shooting Method')
plt.axhline(1, color='red', linestyle='--', label='Desired condition')
plt.legend()
plt.show()
'''