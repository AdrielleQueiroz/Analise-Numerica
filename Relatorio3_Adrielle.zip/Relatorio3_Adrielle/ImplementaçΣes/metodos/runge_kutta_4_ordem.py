def runge_kutta(f, x, y, h, n):
    y_runge_kutta = []
    xi = []

    y_runge_kutta.append(y)
    xi.append(x)

    for i in range(n):
        k1 = f(x, y)
        k2 = f(x + h/2, y + h/2 * k1)
        k3 = f(x + h/2, y + h/2 * k2)
        k4 = f(x + h, y + k3 * h)

        Yn = y + h/6 * (k1 + 2 * k2 + 2 * k3 + k4)
        y_runge_kutta.append(Yn)
        y = Yn
        x += h
        xi.append(x)

    return y_runge_kutta, xi
