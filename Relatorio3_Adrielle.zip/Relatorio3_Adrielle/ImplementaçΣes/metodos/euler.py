def euler(f, x, y, h, n):
    Yn = []
    Xn = []
    Yn.append(y)
    Xn.append(x)

    for i in range(n):
        Yi = y + f(x, y) * h
        y = Yi
        Yn.append(Yi)
        x += h
        Xn.append(x)

    return Yn, Xn
