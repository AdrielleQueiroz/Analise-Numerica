def euler_modificado(f, x, y, h, n):
    y_euler_mod = []
    xi = []

    y_euler_mod.append(y)
    xi.append(x)

    for i in range(n):
        Yn = y + h * f(x + h/2, y + h/2 * f(x, y))
        y_euler_mod.append(Yn)
        y = Yn
        x += h
        xi.append(x)

    return y_euler_mod, xi
