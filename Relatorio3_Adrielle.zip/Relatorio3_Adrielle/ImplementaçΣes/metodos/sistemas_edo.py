def euler(f, x, y, z, h):
    d = f(x, y, z)
    Yn = y + d[0] * h
    Zn = z + d[1] * h

    return Yn, Zn

def sistemas_edo(f, x, y, z, h):
    Yn = []
    Zn = []
    
    for xi in x:
        yi, zi = euler(f, xi, y, z, h)
        Yn.append(yi)
        Zn.append(zi)

        y = yi
        z = zi

    return Yn, Zn