def heun(f, x, y, h, n):
    y_heun = []
    xi = []

    y_heun.append(y)
    xi.append(x)

    for i in range(n):
        Yn = y + ((f(x, y) + f(x + h, y + h * f(x, y))) / 2) * h
        y_heun.append(Yn)
        y = Yn
        x += h
        xi.append(x)

    return y_heun, xi
