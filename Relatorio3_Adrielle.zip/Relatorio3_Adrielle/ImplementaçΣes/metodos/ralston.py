def ralston(f, x, y, h, n):
    y_ralston = []
    xi = []

    y_ralston.append(y)
    xi.append(x)

    for i in range(n):
        k1 = f(x, y)
        k2 = f(x + 3/4 * h, y + 3/4 * k1 * h)

        Yn = y + (1/3 * k1 + 2/3 * k2) * h
        y_ralston.append(Yn)
        y = Yn
        x += h
        xi.append(x)

    return y_ralston, xi
