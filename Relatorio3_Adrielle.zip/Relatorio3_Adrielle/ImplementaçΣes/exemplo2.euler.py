import math
import metodos.euler as euler

def f(x, y):
    return -1.2*y + 7*math.e**(-0.3*x)

def y(x):
    return 70/9*math.e**(-0.3*x) - 43/9*math.e**(-1.2*x)

with open('entrada/exemplo2.txt', 'r') as arquivo:
    valores_str = arquivo.readlines()
    valores = [float(valor.strip()) for valor in valores_str]

x0 = int(valores[0])
y0 = int(valores[1])
h = valores[2]
n = int(valores[3])

yi, xi = euler.euler(f, x0, y0, h, n)

with open('saida/exemplo2_euler.txt', 'w') as arquivo:
    arquivo.write(f"x      y_verdadeiro      y_euler      h=0.5\n\n")

    for Xn, Yn in zip(xi, yi):
        Yv = y(Xn)
        arquivo.write(f"{Xn:.1f}    {Yv:.4f}            {Yn:.4f}\n")