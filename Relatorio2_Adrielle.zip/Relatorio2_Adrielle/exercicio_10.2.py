import metodos.interpolacao_polinomial as ip

def formato_polinomial(coeficientes):
    grau = len(coeficientes) - 1
    polinomio = ""

    for i, coef in enumerate(coeficientes):
        if coef != 0:
            termo = str(coef)
            if i < grau:
                termo += f" * x**{grau - i} + "
            polinomio = termo + polinomio

    return polinomio

valores = []

with open("entradas/exercicio_10.2.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [float(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

x = []
y = []

for i in range(0, len(valores), 2):
    x.append(valores[i])
    y.append(valores[i+1])

coefs = ip.metodo_lagrange(x, 5)
representacao_polinomial = formato_polinomial(coefs)
altitude = ip.p(y, coefs)


with open('saidas/exercicio_10.2.txt', 'w') as file:
        file.write(f"a) Polinômio interpolador: {representacao_polinomial}\nc) Altura do projétil a 5 metros do ponto de lançamento: {altitude}m")
