import matplotlib.pyplot as plt
import numpy as np

import metodos.regressao as regressao

valores = []

with open("entradas/exercicio_8.1.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [int(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

l = []
x = []
y = []

for i in range(0, len(valores), 3):
    l.append(valores[i])
    x.append(valores[i+1])
    y.append(valores[i+2])

a, b, c = regressao.regressao_quadratica(l, y, 2)

# Previsão para o ano 2000
ano_2000 = 2000
previsao_2000 = a * ano_2000**2 + b * ano_2000 + c

print(f"Número de acidentes por 10000 veículos em 2000: {previsao_2000:.3f}")

# Salva a previsão em um arquivo de texto
with open("saidas/exercicio_8.1/exercicio_8.1_b.txt", "w") as arquivo:
    arquivo.write(f"Previsão para o ano 2000: {previsao_2000:.2f} (em milhares)")

# Gerar pontos da curva de regressão
x_reg = np.linspace(min(l), max(l), 100)
y_reg = [a * xi**2 + b * xi + c for xi in x_reg]

# Plotar dados originais e curva de regressão
plt.scatter(l, y, label='Dados Originais', color='blue')
plt.plot(x_reg, y_reg, label='Regressão Quadrática', color='red')
plt.xlabel('Ano')
plt.ylabel('Número de Acidentes por 10000 Veículos')
plt.title('Regressão Quadrática de Acidentes')
plt.legend()
plt.grid(True)
plt.savefig('saidas/exercicio_8.1/exercicio_8.1_b.png')
#plt.show()
