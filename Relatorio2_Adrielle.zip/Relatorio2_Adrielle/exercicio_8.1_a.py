import numpy as np
import matplotlib.pyplot as plt

import metodos.regressao as regressao

valores = []

with open("entradas/exercicio_8.1.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [int(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

l = []
x = []
y = []

for i in range(0, len(valores), 3):
    l.append(valores[i])
    x.append(valores[i+1])
    y.append(valores[i+2])

# Calcula a regressão linear
a0, a1 = regressao.regressao_linear(l, x)

# Previsão para o ano 2000
ano_2000 = 2000
previsao_2000 = a0 + a1 * ano_2000
#print(f"Previsão para o ano 2000: {previsao_2000:.2f} (em milhares)")

# Salva a previsão em um arquivo de texto
with open("saidas/exercicio_8.1/exercicio_8.1_a.txt", "w") as arquivo:
    arquivo.write(f"Previsão para o ano 2000: {previsao_2000:.2f} (em milhares)")

# Visualização do gráfico
def linear(x):
    return a0 + a1 * x

plt.scatter(l, x, label="Dados")
plt.plot(l, [linear(ano) for ano in l], label="Regressão Linear", color="red")
plt.xlabel("Ano")
plt.ylabel("Número de Acidentes (em milhares)")
plt.title("Regressão Linear para Número de Acidentes")
plt.legend()
plt.grid(True)
plt.savefig('saidas/exercicio_8.1/exercicio_8.1_a.png')

