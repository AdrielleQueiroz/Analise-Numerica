import metodos.aproximacao_polinomial as ap

valores = []

with open("entradas/exercicio_8.11.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [float(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

l = []
x = []
y = []

for i in range(0, len(valores), 3):
    l.append(valores[i])
    x.append(valores[i+1])
    y.append(valores[i+2])

k = len(x) - 1
a = l[0]
b = l[len(l) - 1]

def f(x, a, b):
    return a * x**b

coefs_PNB_corrente = ap.aproximacao_continua(f, k, a, b)
print(coefs_PNB_corrente)

# Previsão para o ano 2000
ano_2000 = 2000
previsao_corrente = f(ano_2000, l, x)
previsao_constante = f(ano_2000, l, y)

print(f"Previsão do PNB Corrente para o ano 2000: {previsao_corrente}")