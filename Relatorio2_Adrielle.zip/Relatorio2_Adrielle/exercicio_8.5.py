import metodos.aproximacao_polinomial as ap

import matplotlib.pyplot as plt
import numpy as np

valores = []

with open("entradas/exercicio_8.5.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [float(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

x = []
y = []
k = 2

for i in range(0, len(valores), 2):
    x.append(valores[i])
    y.append(valores[i+1])

coefs = ap.aproximacao_discreta(x, y, k)

with open('saidas/exercicio_8.5/exercicio_8.5_a.txt', 'w') as arquivo:
        arquivo.write('Função Polinomial:\n')
        funcao = f'f(x) = {coefs[0]}'
        for i, coeficiente in enumerate(coefs[1:], 1):
            funcao += f' + {coeficiente}x^{i}'
        arquivo.write(funcao)

# Calcula os valores do polinômio
x_pol = np.linspace(0, 1, 100)
y_pol = [coefs[0] + coefs[1] * x + coefs[2] * x**2 for x in x_pol]

# Plota os valores do polinômio
plt.plot(x_pol, y_pol, label='Polinômio', color='blue')

# Plota os pontos da tabela
plt.scatter(x, y, label='Pontos da Tabela', color='red')

# Configurações do gráfico
plt.xlabel('A/A1')
plt.ylabel('C(x)')
plt.title('Regressão Quadrática')
plt.legend()
plt.grid()

plt.savefig('saidas/exercicio_8.5/exercicio_8.5_b.png')

# Exibe o gráfico
#plt.show()