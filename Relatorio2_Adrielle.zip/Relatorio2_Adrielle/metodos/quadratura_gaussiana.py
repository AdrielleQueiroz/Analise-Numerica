import math

n2 = [(0.5773502692, 1.0000000000), (-0.5773502692, 1.0000000000)]
n3 = [(0.7745966692, 0.5555555556), (0.0000000000, 0.8888888889), (-0.7745966692, 0.5555555556)]

def f(x, T):
    return 0.2 + 25 * x - 200 * x**2 + 675 * x**3 - 900* x**4 + 400 * x**5

def quadratura(f, pontos_e_pesos):
    soma = 0
    for x_k, c_k in pontos_e_pesos:
        soma += c_k * f(x_k)

    return soma

def change(f, a, b, u):
    return f((b + a) / 2 + (b - a) * u / 2) * (b - a) / 2

a, b = [0, 0.8]

def g(u):
    return change(f, a, b, u)

r = quadratura(g, n2)

print("aprox", r)