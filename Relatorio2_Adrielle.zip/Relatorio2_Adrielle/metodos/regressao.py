import numpy as np

# Função de regressão linear
def regressao_linear(x, y):
    n = len(x)
    
    # Calcula os somatórios necessários
    sum_x = sum(x)
    sum_y = sum(y)
    sum_x2 = sum(x_i ** 2 for x_i in x)
    sum_xy = sum(x[i] * y[i] for i in range(n))

    # Calcula os coeficientes a0 e a1
    a1 = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
    a0 = (sum_y - a1 * sum_x) / n

    return a0, a1

def regressao_quadratica(x, y, deg):
    # Ajuste de curva quadrática
    coeff = np.polyfit(x, y, deg)
    a, b, c = coeff

    return a, b, c