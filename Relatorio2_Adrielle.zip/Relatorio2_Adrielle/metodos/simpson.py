import sympy as sp

def multiplo_1_3(f, a, b, n): # Simpsom 1/3
    if n % 2 != 0:
        print("Entrada inválida, você deve entrar com uma número par")
        return 0

    h = (b - a) / n

    soma1 = soma2 = 0

    for i in range(1, int(n / 2 + 1)):
        soma1 += f(a + (2 * i - 1) * h)
    
    for i in range(1, int(n / 2)):
        soma2 += f(a + (2 * i) * h)

    integral = h / 3 * (f(a) + f(b) + 4 * soma1 + 2 * soma2)
    return integral
    #print(f'Integral = {integral:.7f}')

def erro_truncamento_multiplo(f, a, b, c, n):
    # Calcule a quarta derivada
    x = sp.symbols('x')
    quarta_derivada = sp.diff(f, x, 4)
    
    return -((b - a)**5 / (180 * n**4)) * quarta_derivada.subs(x, c)

def simples_1_3(a, b, f):
    # Calcula o valor de h (tamanho do passo)
    h = (b - a) / 2

    # Calcula a aproximação da integral usando a regra de Simpson 1/3 simples
    integral = (h / 3) * (f(a) + 4 * f(a + h) + f(b))

    return integral

def erro_truncamento_simples(f, a, b, c):
    # Calcule a quarta derivada
    x = sp.symbols('x')
    quarta_derivada = sp.diff(f, x, 4)
    
    return -((b - a)**5 / 2880) * quarta_derivada.subs(x, c)

def auxs38(f, a, b): # FUNÇÃO AUXILIAR DO SIMPSON 3/8
    m1 = (2 * a + b) / 3
    m2 = (a + 2 * b) / 3
    integral = (b - a) / 8 * (f(a) + 3 * f(m1) + 3 * f(m2) + f(b))
    return integral

def simpson_3_8(f, a, b, n): # SIMPSON 3/8
    h = (b - a) / n
    soma = 0
    
    for i in range(n):
        b = a + h
        area = auxs38(f, a, b)
        soma += area
        a = b

    return soma #print(f'Integral = {soma:.7f}')

def erro_truncamento_3_8(f, a, b, c, n):
    # Calcule a quarta derivada
    x = sp.symbols('x')
    quarta_derivada = sp.diff(f, x, 4)
    
    return -((b - a)**5 / 6480) * quarta_derivada.subs(x, c)