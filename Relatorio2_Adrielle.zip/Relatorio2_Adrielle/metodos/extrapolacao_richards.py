def somat(f, b, n): # SOMATÓRIO - fUNÇÃO UTILIZADA PELAS REGRAS DO TRAPEZIO
    temp = b / n
    som = y = 0
    for c in range(n - 1):
        y += temp
        som += f(y)
    return som

# n = 1, Integral simples
# n > 1, Integral composta
def it_simples_e_composta(f, a, b, n): # Regra do trapézio
    I = (b - a) * (f(a) + (2 * somat(f, b, n)) + f(b)) / (2 * n)
    print(f'{I:.4f}')
    return I

def extrapolacao_de_richard(f, a, b): # Utiliza o resultado da Regra do trapézio
    # 4/3 e 1/3
    print(f'Extrapolacao 4/3 n2 - n1: {(4 / 3) * it_simples_e_composta(f, a, b, 2) - (1 / 3) * it_simples_e_composta(f, a, b, 1):.7f}')
    print(f'Extrapolacao 4/3 n4 - n2 : {(4 / 3) * it_simples_e_composta(f, a, b, 4) - (1 / 3) * it_simples_e_composta(f, a, b, 2):.7f}')
    # 16/15 e 1/15
    print(f'Extrapolacao 16/15 n12 - n3: {(16 / 15) * it_simples_e_composta(f, a, b, 12) - (1 / 15) * it_simples_e_composta(f, a, b, 3):.7f}')

def f(x):
    return -588.5416666666661 + 222.97123015873058*x + -11.512896825396837*x**2 + 0.28591269841269895*x**3 + -0.00257936507936507*x**4

a = float(line[0][0])
b = float(line[len(line)-2][0])