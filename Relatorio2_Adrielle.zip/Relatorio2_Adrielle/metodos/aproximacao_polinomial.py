import metodos_auxiliares.eliminacao_gauss as eg
import numpy as np

def aproximacao_discreta(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('Número de pontos insuficiente')
    
    somas = {}
    somas[0] = n

    for n in range(1, 2 * k + 1):
        somas[n] = sum(xi ** n for xi in x)

    A = []
    B = []

    for i in range(k + 1):
        row = []

        for j in range(k + 1):
            row.append(somas[i + j])
        
        A.append(row)

        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))

    coefs = eg.eliminacao_gauss(A, B)

    return coefs

def aproximacao_continua(f, k, a, b):
    def integrand(a, b):
        return lambda x: a * x ** b

    n = k + 1
    A = np.zeros((n, n))
    B = np.zeros(n)
    
    # Vetor x (pontos de integração)
    x = np.linspace(a, b, 1000)  # Dividindo o intervalo [a, b] em 1000 pontos

    for i in range(n):
        for j in range(n):
            integrand_ij = integrand(i, j)
            A[i, j] = np.trapz(integrand_ij(x), x)
    
    for i in range(n):
        integrand_i = lambda x: f(x) * x ** i
        B[i] = np.trapz(integrand_i(x), x)

    coefficients = np.linalg.solve(A, B)
    return coefficients

'''
import numpy as np

def aproximacao_continua(f, k, a, b):
    def integrand(i, j):
        return lambda x: x ** (i + j)

    n = k + 1
    A = np.zeros((n, n))
    B = np.zeros(n)
    
    # Vetor x (pontos de integração)
    x = np.linspace(a, b, 1000)  # Dividindo o intervalo [a, b] em 1000 pontos

    for i in range(n):
        for j in range(n):
            integrand_ij = integrand(i, j)
            A[i, j] = np.trapz(integrand_ij(x), x)
    
    for i in range(n):
        integrand_i = lambda x: f(x) * x ** i
        B[i] = np.trapz(integrand_i(x), x)

    coefficients = np.linalg.solve(A, B)
    return coefficients

# Função que corresponde a a * x^b
def f(x, a, b):
    return a * x ** b

# Grau do polinômio
k = 2

# Limites de integração
a = 0.10  # Início da tabela de dados
b = 1.00  # Fim da tabela de dados

# Aproximação contínua para a e b
coefs = aproximacao_continua(lambda x: f(x, a, b), k, a, b)

# Ano de 2000
ano_2000 = 2000
previsao_pnb = f(ano_2000, coefs[0], coefs[1])

print(f"Previsão do PNB para o ano 2000: {previsao_pnb}")
'''