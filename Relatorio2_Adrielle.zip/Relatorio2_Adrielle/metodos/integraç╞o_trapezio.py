from sympy import diff, symbols, integrate

def trapezoidal_integration(f, a, b):
    # Calcula a integral aproximada da função f no intervalo [a, b] usando um único trapézio.
    h = b - a  # Largura do intervalo
    fa = f(a)  # Valor da função no ponto 'a'
    fb = f(b)  # Valor da função no ponto 'b'
    
    integral = (h / 2) * (fa + fb)  # Fórmula do trapézio
    
    return integral

def erro_truncamento(f, a, b):
    x = symbols('x')
    primeira_derivada = diff(f(x), x)
    segunda_derivada = diff(primeira_derivada, x)

    media_f = integrate(segunda_derivada, (x, a, b)) / b - a
    print(media_f)

    return -1/12 * media_f * (b - a)**3

def trapezoidal_integration(f, a, b, n):
    # Calcula a integral aproximada da função f no intervalo [a, b] usando n trapézios.
    h = (b - a) / n  # Largura de cada subintervalo
    integral = 0.5 * (f(a) + f(b))  # Inicializa a integral com as extremidades
    
    for i in range(1, n):
        x_i = a + i * h  # Ponto x no início do trapézio
        integral += f(x_i)  # Soma o valor da função no ponto x_i
    
    integral *= h  # Multiplica pela largura do trapézio
    
    return integral