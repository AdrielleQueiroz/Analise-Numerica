def metodo_lagrange(x, v):
    n = len(x)
    coeficientes = []

    for i in range(n):
        L = 1

        for j in range(n):
            if i != j:
                L *= (v - x[j]) / (x[i] - x[j])

        coeficientes.append(L)

    return coeficientes

def p(y, coeficientes):
    return sum(y * l for y, l in zip(y, coeficientes))

def diferenca_dividida(x, y):
    n = len(x)
    tabela = [[0] * n for _ in range(n)]

    for i in range(n):
        tabela[i][0] = y[i]

    for j in range(1, n):
        for i in range(n - j):
            tabela[i][j] = (tabela[i + 1][j - 1] - tabela[i][j - 1]) / (x[i + j] - x[i])

    return tabela[0]

def interpolacao_newton(x, y, X):
    coeficientes = diferenca_dividida(x, y)
    n = len(x)
    resultado = coeficientes[0]

    for i in range(1, n):
        termo = coeficientes[i]
        for j in range(i):
            termo *= (X - x[j])
        resultado += termo

    return resultado