from sympy import *

x = symbols("x")

def interval(x0, xn, h):
    xi = [x0]
    aux = x0 + h

    while (aux < xn):
        xi.append(aux)
        aux = aux + h
    
    xi.append(aux)
    return xi

def multipleTrapezoids(func, a, b, n):
    h = (b - a) / n
    xi = interval(a, b, h)
    l = len(xi)
    result = func.subs(x, a) + func.subs(x, b)

    for i in range(1, l - 1):
        result = result + 2 * func.subs(x, xi[i])
    
    result = result * h / 2
    return result

def richardson(func, a, b):
	Ih1 = multipleTrapezoids(func, a, b, 4)
	print(Ih1)
	Ih2 = multipleTrapezoids(func, a, b, 2)
	print(Ih2)

	return (4 / 3 * Ih1) - (1 / 3 * Ih2)
	

with open('entrada.txt', 'r') as f:
    lines = f.readlines()
    func = eval(lines[0].strip())
    values = [float(valor) for valor in lines[1].split()]

result = richardson(func, values[0], values[1])

with open('saida.txt', 'w') as f:
    f.write(f"I(f(x)) =  {result}")