import metodos.interpolacao_polinomial as ip

valores = []

with open("entradas/exercicio_10.6.txt") as arquivo:
    valores_convertidos = []
    linhas = arquivo.readlines()

    for linha in linhas:
        # Divide a linha em valores usando espaços em branco como separadores
        valores_linha = linha.split()

        # Converte os valores para o tipo de dado desejado (int float, etc..)
        valores_convertidos = [float(valor) for valor in valores_linha]

        # Adiciona os valores à lista de valores
        valores.extend(valores_convertidos)

x = []
y = []

for i in range(0, len(valores), 2):
    x.append(valores[i])
    y.append(valores[i+1])

# Comprimentos desejados para interpolação
comprimento1 = 1730
comprimento2 = 3200

resistencia_interpolada = ip.interpolacao_newton(x[1:4], y[1:4], comprimento1)
resultado1 = f"Resistência estimada para 1730 m usando parábola de 2° grau: {resistencia_interpolada:.2f} Ohms\n"
resistencia_interpolada = ip.interpolacao_newton(x[1:5], y[1:5], comprimento1)
resultado1 += f"Resistência estimada para 1730 m usando parábola de 3° grau: {resistencia_interpolada:.2f} Ohms"

resistencia_interpolada = ip.interpolacao_newton(x[4:7], y[4:7], comprimento2)
resultado2 = f"Resistência estimada para 3200 m usando parábola de 2° grau: {resistencia_interpolada:.2f} Ohms\n"
resistencia_interpolada = ip.interpolacao_newton(x[4:8], y[4:8], comprimento2)
resultado2 += f"Resistência estimada para 3200 m usando parábola de 3° grau: {resistencia_interpolada:.2f} Ohms"

with open('saidas/exercicio_10.6.txt', 'w') as file:
        file.write("a)\n" + resultado1 + "\n\n" + "b)\n" + resultado2)
