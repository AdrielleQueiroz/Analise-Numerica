import numpy as np

def substituicoes_sucessivas(A, b):
    '''Executa o método das substituições sucessivas para resolver o sistema 
       linear triangular inferior Ax=b.
       Parâmetros de entrada: A é uma matriz triangular inferior e b é o vetor constante. 
       Saída: vetor x
    '''

    # n é a ordem da Matriz A
    n = len(A)

    x = n * [0]
    for i in range(0, n):
        s = 0

        for j in range(0, i):
            s = s + A[i][j] * x[j]

        x[i] = (b[i] - s) / A[i][i]

    return x

def identidade(n):
    '''Cria uma matriz identidade de ordem n.
    Parâmetros de entrada:  n é a ordem da matriz.
    Saída: matriz identidade de ordem n.
    '''

    m = []

    for i in range(0, n):
        linha = [0] * n
        linha[i] = 1
        m.append(linha)

    return m

def fatoracao_LU(A):
    '''
    Decompõe a matriz A no produto de duas matrizes L e U. Onde L é uma matriz 
    triangular inferior unitária e U é uma matriz triangular superior.
    Parâmetros de entrada: A é uma matriz quadrada de ordem n.
    Saída: (L,U) tupla com as matrizes L e U
    '''

    n = len(A)

    # Inicializa a matriz L com a matriz identidade
    L = identidade(n)

    for k in range(0, n - 1):
        
        # Para cada linha i
        for i in range(k + 1, n):
            
            # calcula o fator m
            m = - A[i][k] / A[k][k]
            L[i][k] = -m

            # Atualiza a linha i da matriz, percorrendo todas as colunas j
            for j in range(k + 1, n):
                A[i][j] = m * A[k][j] + A[i][j]

            # Zera o elemento Aik
            A[i][k] = 0

    return (L, A)

def substituicoes_retorativas(A, b):
    '''Executa o método das substituições retroativas para resolver o sistema 
       linear triangular superior Ax=b.
       Parâmetros de entrada: A é uma matriz triangular superior e b é o vetor constante. 
    '''

    # n é a ordem da matrzi A
    n = len(A)

    # Inicializa o vetor x com o tamanho de n e elementos iguais a 0
    x = n * [0]

    for i in range(n - 1, -1, -1):
        s = 0

        for j in range(i + 1, n):
            s = s + A[i][j] * x[j]

        x[i] = (b[i] - s) / A[i][i]

    return x

def lux(L, U, b):
    '''
    Resolve o sistema LUx=b.
    Esse método resolve os dois sistemas lineares triangulares.
    Parâmetros de entrada: L é uma matriz triangular inferior de ordem n,
    U é uma matriz triangular superior e b é o vetor constante.
    Saída: vetor x solução do sistema.
    '''

    y = substituicoes_sucessivas(L, b)
    x = substituicoes_retorativas(U, y)

    return x
