def ponto_fixo(g, x0, erro, max_iter=100):
    """
    Método do Ponto Fixo para encontrar uma raiz de uma função.
    """
    
    # Inicializa a aproximação inicial
    x = x0
    
    # Realiza iterações até atingir o limite máximo
    for i in range(max_iter):
        # Aplica a função de iteração
        x_prox = g(x)
        
        # Calcula o erro absoluto
        erro_abs = abs(x_prox - x)
        
        # Verifica se o erro é menor que a tolerância
        if erro_abs < erro:
            return x_prox  # Retorna a aproximação encontrada
        
        # Atualiza a aproximação
        x = x_prox
    
    # Se o número máximo de iterações for atingido, retorna o valor atual
    return x
