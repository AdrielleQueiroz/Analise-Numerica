import math
import numpy as np

# Método newton-raphson
def newton_raphson(f, df, x0, erro):
    Er = 1
    x = x0

    while(Er >= erro):
      xold = x
      x = xold - (f(xold) / df(xold))
      Er = np.abs((x - xold) / x)

    return x
