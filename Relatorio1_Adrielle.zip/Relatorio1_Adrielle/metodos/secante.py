import math
import numpy as np

# Método da Secante
def secante(f, x0, x1, erro):
    Er = 1
    xold1 = x0
    x = x1

    while(Er >= erro):
      xold2 = xold1
      xold1 = x
      x = (f(xold1) * xold2 - f(xold2) * xold1) / (f(xold1) - f(xold2))
      Er = np.abs((x - xold1) / x)

    return x