def bisseccao(f, a, b, eps, maxIter = 50):
    """
        Executa o método da bisseção para achar o zero de f no intervalo 
        [a,b] com precisão epsilon. O método executa no máximo maxIter iterações.
        Retorna uma tupla (houveErro, raiz), onde houveErro é booleano.
    """

    # Inicializar as variaveis Fa e Fb os valores de f(a) e f(b)
    Fa = f(a)
    Fb = f(b)

    # Inicializa o tamanho do intervalo intervX usando a função abs, x e Fx
    intervX = abs(b - a)
    x = (a + b) / 2
    Fx = f(x)

    # Testa se o intervalo já é do tamamanho da precisão e retorna a raiz sem erros
    if intervX <= eps:
        return (False, x)
    
    # Inicializa o k
    k = 1

    # Se a função não mudar de sinal entre a e x, então atualiza o a e Fa.
    # Caso contrário, atualiza o b e Fb
    while k <= maxIter:
        if Fa * Fx > 0:
            a = x
            Fa = Fx
        else:
            b = x
            Fb = Fx

        # Atualiza intervX, x, Fx
        intervX = abs(b - a)
        x = (a + b) / 2
        Fx = f(x)

        # Testa o critério de parada (Usando apenas o tamanho do intervalo) 
        if intervX <= eps:
            return (False, x)
        
        # Incrementa o k
        k = k + 1
