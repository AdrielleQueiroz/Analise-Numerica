import numpy as np
import metodos.bisseccao as bisseccao
import metodos.ponto_fixo as ponto_fixo
import metodos.newton_raphson as newton_raphson
import metodos.secante as secante

def f(x):
    return 31 - ((9.8 * x) / 13) * (1. - np.exp(-6.0 * (13.0 / x)))

def df(x):
    return np.exp(-78.0 / x) * (9.8 / 13.0 + 58.8 / x) - 9.8 / 13.0

# Abre os arquvios com os dados de entrada e os atribui a uma lista
with open('entrada/exemplo2.txt', 'r') as dados_entrada:
    lista = []
    for i in dados_entrada.readlines():
        lista.append(i.strip())

# Atribui os dados de entrada as variáveis
a = int(lista[0])
b = int(lista[1])
eps = float(lista[2])

''' Bissecção '''
x = bisseccao.bisseccao(f, a, b, eps)

with open('saida/exemplo2.txt', 'w') as arquivo:
    arquivo.write("Método da Bissecção\nRaiz encontrada: " + str(x[1]))

''' Posição falsa '''
'''
x = ponto_fixo.ponto_fixo(f, a, eps)

with open('saida/exemplo2.txt', 'a') as arquivo:
    arquivo.write("\n\nMétodo da Posição Falsa\nRaiz encontrada: " + str(x))
'''
''' Newton-Raphson '''
x = newton_raphson.newton_raphson(f, df, a, eps)

with open('saida/exemplo2.txt', 'a') as arquivo:
    arquivo.write("\n\nMétodo de Newton-Raphson\nRaiz encontrada: " + str(x))

''' Método da secante '''
x = secante.secante(f, a, b, eps)

with open('saida/exemplo2.txt', 'a') as arquivo:
    arquivo.write("\n\nMétodo da secante\nRaiz encontrada: " + str(x))