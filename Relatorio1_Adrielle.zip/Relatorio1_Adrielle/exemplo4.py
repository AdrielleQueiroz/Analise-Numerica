import metodos.jacobi as jacobi
import metodos.gauss_seidel as seidel

A = []
b = []
eps = None

# Abre o arquivo em modo de leitura
with open('entrada/exemplo4.txt', 'r') as arquivo:
    lendo_matriz = True
    lendo_lista = True

    # Lê o arquivo linha por linha
    for linha in arquivo:
        linha = linha.strip()  # Remove espaços em branco e quebras de linha

        # Verifica se a linha é uma linha de delimitação
        if linha == "*****":
            if lendo_matriz:
                lendo_matriz = False
            elif lendo_lista:
                lendo_lista = False
            else:
                break  # Saímos do loop quando todas as seções foram lidas
        else:
            elementos = [float(elemento) for elemento in linha.split()]
            if lendo_matriz:
                A.append(elementos)
            elif lendo_lista:
                b.extend(elementos)
            else:
                eps = float(linha)

''' Método de Jacobi '''
x = jacobi.jacobi(A, b, eps)

with open('saida/exemplo4.txt', 'w') as arquivo:
    arquivo.write("Vetor A:\n")
    
    for i in range(len(A)):
        for j in range(len(A)):
            arquivo.write("[" + str(A[i][j]) + "] ")

        arquivo.write("\n")

    arquivo.write("\nVetor b:\n" + str(b))
    arquivo.write("\n\nMétodo de Jacobi:\nVetor resultante: " + str(x))

''' Método de Gauss-Seidel '''

x = seidel.gauss_seidel(A, b, eps)

with open('saida/exemplo4.txt', 'a') as arquivo:
    arquivo.write("\n\nMétodo de Gauss-Seidel:\nVetor resultante: " + str(x))